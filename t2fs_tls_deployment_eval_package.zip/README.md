# T2FS-TLS Deployment Evaluation Pack

This pack strengthens the evaluation section without fabricating hardware data.

## What is generated now

- Protocol-level byte accounting for T2FS-MLWE-512-IoT and T2FS-MLWE-768-IoT.
- 500 fixed-seed validation runs per profile.
- Replay, tamper, wrong-hint, wrong-FO-tag, and Finished-mismatch abort-stage checks.
- T2FS lifecycle state and KeyUpdate byte-saving results.
- Paper-ready LaTeX tables and section text.

## What requires target logs

The following values are intentionally populated only from CSV logs:

- Handshake latency for TLS 1.3 ECDHE, ML-KEM-512-TLS, Hybrid TLS, OQS-TLS, KEMTLS, and T2FS-TLS.
- Energy per handshake, with at least 100 handshakes per protocol and target.
- Flash, static SRAM, peak stack, heap mode, and peak heap.
- End-to-end latency, throughput, and packet loss.

## Run

```bash
python3 run_deployment_eval.py > run_output.txt
pdflatex -interaction=nonstopmode deployment_eval_standalone.tex
pdflatex -interaction=nonstopmode deployment_eval_standalone.tex
```

## Add hardware logs

Fill the CSV templates in `input_logs/`:

- `resource_logs.csv`
- `handshake_logs.csv`
- `energy_logs.csv`
- `network_logs.csv`
- `attack_logs.csv`

Then rerun `python3 run_deployment_eval.py`.
