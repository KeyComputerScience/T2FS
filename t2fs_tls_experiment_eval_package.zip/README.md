# T2FS-TLS Experiment Section and Generated Results

This folder contains a replacement experiment section for the T2FS-TLS paper.
It removes unsupported hardware claims and reports reproducible protocol-level
evidence generated from the FO-enhanced reference implementation.

## Files

- `run_t2fs_experiments.py`: runs the deterministic experiment generator.
- `t2fs_experiment_results.json`: generated machine-readable results.
- `t2fs_experiment_tables.tex`: generated LaTeX tables.
- `t2fs_experiment_section.tex`: paper-ready LaTeX experiment section.
- `t2fs_experiment_section_standalone.tex`: standalone wrapper for compilation.
- `t2fs_experiment_section_standalone.pdf`: compiled preview.
- `run_output.txt`: captured command-line output.

## Run

```bash
python3 run_t2fs_experiments.py > run_output.txt
pdflatex -interaction=nonstopmode t2fs_experiment_section_standalone.tex
pdflatex -interaction=nonstopmode t2fs_experiment_section_standalone.tex
```

The generated results are protocol-level deterministic results. Board-level
latency, energy, Flash, SRAM, and stack usage must be reported only after
collecting target-device logs.
