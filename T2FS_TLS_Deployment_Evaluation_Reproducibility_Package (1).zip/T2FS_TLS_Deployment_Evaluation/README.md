# T2FS-TLS IoT Deployment Evaluation Reproducibility Package

This package provides scripts and templates for collecting and analyzing:
- memory footprint
- handshake latency
- energy consumption
- security validation

The package does not contain fabricated hardware measurements.
After collecting real device logs, place CSV files under logs_template/ and run:

chmod +x reproduce.sh
./reproduce.sh
