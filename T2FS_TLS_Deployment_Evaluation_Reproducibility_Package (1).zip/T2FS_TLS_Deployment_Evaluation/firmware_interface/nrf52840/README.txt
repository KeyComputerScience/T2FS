Contiki-NG/wolfSSL integration interface.
