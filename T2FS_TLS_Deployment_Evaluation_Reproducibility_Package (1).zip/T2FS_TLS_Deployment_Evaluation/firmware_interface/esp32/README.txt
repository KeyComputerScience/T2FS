ESP-IDF/mbedTLS integration interface.
