STM32/wolfSSL integration interface.
