Place STM32 logs here.
