Place ESP32 logs here.
